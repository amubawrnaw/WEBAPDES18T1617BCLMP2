package mp2.Model;

import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.tomcat.util.codec.binary.Base64;

public class Photo {
	private String uploader;
	private boolean isPublic;
	private String description;
	private Blob image;
	private String[] tags;
	private String title;
	private int id;
	
	public Photo(String uploader, boolean isPublic, String description, Blob blob, String[] tags, String title, int id) {
		this.uploader = uploader;
		this.isPublic = isPublic;
		this.description = description;
		this.image = blob;
		this.tags = tags;
		this.title = title;
		this.id = id;
	}
	public Photo(){
		uploader = "null";
		isPublic = false;
		description = "null";
		tags = new String[]{"null"};
		id = -1;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String[] getTags() {
		return tags;
	}
	public void setTags(String[] stag) {
		this.tags = stag;
	}
	public Blob getImage() {
		return image;
	}
	public void setImage(Blob image) {
		this.image = image;
	}
	public String getUploader() {
		return uploader;
	}
	public void setUploader(String uploader) {
		this.uploader = uploader;
	}
	public boolean isPublic() {
		return isPublic;
	}
	public void setPublic(boolean isPublic) {
		this.isPublic = isPublic;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public static Photo toPhoto(ResultSet rs, String[] tags){
		Photo photo = new Photo();
		try{
			if(!rs.next()){
				System.out.println("empty rs");
			}else{
				photo.setDescription(rs.getString("description"));
				photo.setImage(rs.getBlob("image"));
				photo.setPublic(rs.getBoolean("public"));
				photo.setTags(tags);
				photo.setUploader(rs.getString("uploader"));
				photo.setTitle(rs.getString("title"));
				photo.setId(rs.getInt("imageId"));
				return photo;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return photo;
	}
	public static Photo toPhoto(ResultSet rs){
		Photo photo = new Photo();
		try{
			photo.setDescription(rs.getString("description"));
			photo.setImage(rs.getBlob("image"));
			photo.setPublic(rs.getBoolean("public"));
			photo.setUploader(rs.getString("uploader"));
			photo.setTitle(rs.getString("title"));
			photo.setId(rs.getInt("imageId"));
			return photo;
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return photo;
	}
	
	private String tagToString(){
		String str = "";
		for(int i = 0 ; i < tags.length ; i++){
			str+=tags[i];
			if(i != tags.length - 1){
				str+=",";
			}
		}
		return str;
	}
	
	private String encode(){
		try {
			byte[] bytes = image.getBytes(1, (int)image.length());
			String encodedStr = Base64.encodeBase64String(bytes);
			return encodedStr;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}
	
	public String toJSON(){
		String json = "{"
				+ "\"title\": \"" + title + "\","
				+ "\"image\": \"" + encode() + "\","
				+ "\"description\": \"" + description + "\","
				+ "\"tags\": \"" + tagToString() + "\","
				+ "\"id\": \"" + id + "\","
				+ "\"uploader\": \"" + uploader + "\","
				+ "\"public\": \"" + isPublic + "\""
				+ "}";
		return json;
	}
}
