package mp2.Control;

import java.sql.ResultSet;
import java.sql.SQLException;

import mp2.Model.DBConnection;
import mp2.Model.User;

public class UserHandler {
	private DBConnection dbc;
	public UserHandler(){
		dbc = new DBConnection();
		dbc.getConnection();
	}
	//returns true if login successful
	public boolean login(String username, String password){
		String query = "SELECT * FROM user WHERE username = '"+username
				+"' AND password = '" + password + "'";
		ResultSet rs = dbc.executeQuery(query);
		try {
			if(rs.next()){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean register(String username, String password, String desc){
		String query = "SELECT * FROM user WHERE username = '" + username + "'";
		ResultSet rs = dbc.executeQuery(query);
		boolean success = false;
		try {
			if(!rs.next()){
				query = "INSERT INTO user(username,password,description)"
						+ " VALUES('"+ username +"', '" + password + "','"+desc+"')";

				dbc.updateQuery(query);
				success = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(!success)
			System.out.println("username already used");
		return success;
	}
	
	public User getUser(String user){
		String query = "SELECT * FROM user WHERE username = '" + user + "'";
		ResultSet rs = dbc.executeQuery(query);
		try {
			rs.next();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return User.toUser(rs);
	}
	
	
}
