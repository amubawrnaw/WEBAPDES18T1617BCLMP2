package mp2.Control;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import mp2.Model.DBConnection;
import mp2.Model.Photo;

public class ImageHandler {
	private DBConnection dbc;
	public ImageHandler(){
		dbc = new DBConnection();
		dbc.getConnection();
	}
	public void addPhoto(String upload, String desc,Boolean isPublic, String path, String title, String[] tags, String[] users){
		//type 0-public 1-private
		String query = "INSERT INTO images(image,uploader,description,public, title) VALUES(?,?,?,?,?)";
		try{
			File file = new File(path);
			FileInputStream fis = new FileInputStream(file);
			System.out.println(path);
			PreparedStatement pstmt = dbc.createPreparedStatement(query);
			
			pstmt.setBinaryStream(1, fis);
			pstmt.setString(2, upload);
			pstmt.setString(3, desc);
			pstmt.setBoolean(4, isPublic);
			pstmt.setString(5, title);
			pstmt.executeUpdate();
			pstmt.close();
			
			query = "SELECT * FROM images WHERE uploader = '" + upload + "' ORDER BY imageId desc";
			ResultSet rs = dbc.executeQuery(query);
			rs.next();
			
			int imageId = rs.getInt("imageId");
			
			for(int i = 0 ; i < tags.length ; i++){
				addTag(tags[i], String.valueOf(imageId));
			}
			System.out.println(users[0]);
			for(int i = 0 ; i < users.length ; i++){
				sharePhoto(String.valueOf(imageId), users[i]);
				System.out.println(users[i]);
			}
			
			System.out.println("photo added!");
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void addPhoto(String upload, String desc,Boolean isPublic, String path, String title, String[] tags){
		//type 0-public 1-private
		String query = "INSERT INTO images(image,uploader,description,public, title) VALUES(?,?,?,?,?)";
		try{
			
			File file = new File(path);
			FileInputStream fis = new FileInputStream(file);
			PreparedStatement pstmt = dbc.createPreparedStatement(query);
			BufferedImage bi;
			pstmt.setBinaryStream(1, fis);
			pstmt.setString(2, upload);
			pstmt.setString(3, desc);
			pstmt.setBoolean(4, isPublic);
			pstmt.setString(5, title);
			
			
			pstmt.executeUpdate();
			pstmt.close();
			
			query = "SELECT * FROM images WHERE uploader = '" + upload + "' ORDER BY imageId desc";
			ResultSet rs = dbc.executeQuery(query);
			rs.next();
			
			int imageId = rs.getInt("imageId");
			
			for(int i = 0 ; i < tags.length ; i++){
				addTag(tags[i], String.valueOf(imageId));
			}
			
			System.out.println("photo added!");
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	//add tags
	public void addTag(String tagname, String imageId){
		//check if tag exists, if not, create new tag, if it exists, use the existing tag id
		String query = "SELECT * FROM tags WHERE tagname = '" + tagname +"'";
		ResultSet rs = dbc.executeQuery(query);
		try {
			if(rs.next()){
				int tagId = rs.getInt("tagId");
				query = "INSERT INTO image_tag(imageId, tagId) VALUES('" + imageId + "', '" + tagId + "')";
				dbc.updateQuery(query);
			}else{
				query = "INSERT INTO tags(tagname) VALUES('" + tagname + "')";
				dbc.updateQuery(query);
				addTag(tagname, imageId);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//returns tag given image id
	public String[] getTags(int id){
		String query = "SELECT * FROM tags t, image_tag it WHERE "
					+ "it.imageId = " + id + " AND t.tagId = it.tagId";
		
		String[] tags = null;
		try{
			ResultSet rs = dbc.executeQuery(query);
			ArrayList<String> arrStr = new ArrayList<>();
			
			while(rs.next()){
				arrStr.add(rs.getString("tagname"));
			}
			
			tags = new String[arrStr.size()];
			for(int i = 0 ; i < arrStr.size(); i++){
				tags[i] = arrStr.get(i);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return tags;
	}
	
	public Photo[] allPublic(){
		String query = "SELECT * FROM images WHERE public = 1";
		Photo[] photos = null;
		try{
			ResultSet rs = dbc.executeQuery(query);
			ArrayList<Photo> list = new ArrayList<>();
			while(rs.next()){
				Photo ph = Photo.toPhoto(rs);
				ph.setTags(getTags(ph.getId()));
				list.add(ph);
			}
			if(!list.isEmpty()){
				photos = new Photo[list.size()];
				for(int i = 0 ; i < list.size() ; i++){
					photos[i] = list.get(i);
				}
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return photos;
	}
	
	public void sharePhoto(String imageId, String username){
		String query = "SELECT * FROM user WHERE username = '" + username + "'";
		ResultSet rs = dbc.executeQuery(query);
		try {
			//check if user exists
			if(rs.next()){
				query = "INSERT INTO allowedusers(photoId, username) VALUES ('"+ imageId +"', '" + username + "')";
				dbc.updateQuery(query);
			}else{
				System.out.println("USER DOES NOT EXIST");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Photo[] getPhotoByUserId(String username){
		Photo[] photos = null;
		String query = "SELECT * FROM images i WHERE uploader = '" + username + "'";
		try{
			ResultSet rs = dbc.executeQuery(query);
			ArrayList<Photo> list = new ArrayList<>();
			while(rs.next()){
				Photo ph = Photo.toPhoto(rs);
				ph.setTags(getTags(ph.getId()));
				list.add(ph);
			}
			if(!list.isEmpty()){
				photos = new Photo[list.size()];
				for(int i = 0 ; i < list.size() ; i++){
					photos[i] = list.get(i);
				}
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return photos;
		
		
	}
	
	
	public Photo[] getPhotoByShare(String username){
		Photo[] photos = null;
		String query = "SELECT * FROM images i, allowedusers a"
				+ " WHERE a.username = '" + username
				+ "' AND a.photoId = i.imageId";
		
		try{
			ResultSet rs = dbc.executeQuery(query);
			ArrayList<Photo> list = new ArrayList<>(); 
			while(rs.next()){
				Photo ph = Photo.toPhoto(rs);
				ph.setTags(getTags(ph.getId()));
				list.add(ph);
			}
			if(!list.isEmpty()){
				photos = new Photo[list.size()];
				for(int i = 0 ; i < list.size() ; i++){
					photos[i] = list.get(i);
				}
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return photos;
	}
	
	public Photo[] getPhotoByTag(String tagName){
		Photo[] photos = null;
		String query = "SELECT * FROM images i, image_tag it, tags t"
						+ " WHERE t.tagname = '" + tagName + "'"
						+ " AND t.tagId = it.tagId"
						+ " AND it.imageId = i.imageId"
						+ " AND i.public = 1";
		
		try{
			ResultSet rs = dbc.executeQuery(query);
			ArrayList<Photo> list = new ArrayList<>();
			while(rs.next()){
				Photo ph = Photo.toPhoto(rs);
				ph.setTags(getTags(ph.getId()));
				list.add(ph);
			}
			if(!list.isEmpty()){
				photos = new Photo[list.size()];
				for(int i = 0 ; i < list.size() ; i++){
					photos[i] = list.get(i);
				}
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return photos;
	}
	
	public Photo getPhotoByPhotoId(String id){
		Photo photo = null;
		String query = "SELECT * FROM images WHERE imageId = " + id;
		try{
			String[] tags = getTags(Integer.parseInt(id));
			ResultSet rs = dbc.executeQuery(query);
			rs.next();
			photo = Photo.toPhoto(rs, tags);
			 return photo;
		}catch(Exception e){
			e.printStackTrace();
		}
		return photo;
	}
	/*
	 * 
	 * 
	 * incomplete code
	public Blob[] getPhotos(String query){
		Blob[] blobs = null;
		ArrayList<Blob> blob = new ArrayList<>();
		ResultSet rs = dbc.executeQuery(query);
		try{
			while(rs.next()){
				 blob.add(rs.getBlob("image"));
			}
			
			blobs = new Blob[blob.size()];
			
			for(int i = 0 ; i < blob.size() ; i++){
				blobs[i] = blob.get(i);
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		
		
		return blobs;
	}
	*/
	
}
